=== SOFG Newsletter ===
Contributors: anandlovessofg,vrajesh.dave,Vala bhavesh,maliyaumeshl
Tags: newsletter,autoupdater
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3

This is really awesome plugin to send email to subscribers users and newsletter subscriptions.It has also auto new feature to send auto update to related subscribe category. Use this short code  [SOFG_NEWSLETTER_FRONT]  to display newsletter fronted.

== Description ==
This function Includes the number of functions.
some of the function will be activated on further version.my current wordpress includes following function.
1. Newsletter subscription function
2. newsletter subscription based on post category post.
3. Auto updater option. (once the post added to blogs it will notify the users based on their subscription)
4. It includes the various mail a) confirm mail b) welcome mail c) unsubscription mail d) new update link
5. send mail to only confirm users
6. send mail to all users.   

== Installation ==
1. Upload `sofg-newsletter` to the `/wp-content/plugins/` directory
2. Activate the plugin through the \\\'Plugins\\\' menu in WordPress
3. Place the short code : 
A) For page : [SOFG_NEWSLETTER_FRONT]
B) For Template file :   echo do_shortcode( '[SOFG_NEWSLETTER_FRONT]' );


== Frequently Asked Questions ==
= how to see various plug-in setting ? =
1. go to wordpress back end.
2. navigate to the setting menu in wordpress.
3. click on \"sofg newsletter setting\" option. 
= how enable auto update function ? =
1. on plugin setting page we have the option called \"Enable Auto update User\" click on enable.


== Screenshots ==
1. sofg setting page
2. send mail to subscribers
3. subscription list
