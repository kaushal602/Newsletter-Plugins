<?php
	wp_enqueue_style( 'sofg-plugin-style' );
	if(isset($_POST['update_subscriber'])){
		if(!empty($_POST["password"])){  
		 $userdata = array(
		'ID'          =>  intval($_POST["sofguserid"]),
		'user_url'    =>  sanitize_text_field($_POST["website"]),
		'user_pass'   =>  sanitize_text_field($_POST["password"]),
		'user_email'  =>  sanitize_email($_POST["email"]),
		'first_name'  =>  sanitize_text_field($_POST["firstname"]),
		'last_name'   =>  sanitize_text_field($_POST["lastname"]),
		'description' =>  sanitize_text_field($_POST["bio-info"]),
		'role'  =>   'Subscriber');
		}
		else{
		$userdata = array(
		'ID'          =>  intval($_POST["sofguserid"]),
		'user_url'    =>  sanitize_text_field($_POST["website"]),
		'user_email'  =>  sanitize_email($_POST["email"]),
		'first_name'  =>  sanitize_text_field($_POST["firstname"]),
		'last_name'   =>  sanitize_text_field($_POST["lastname"]),
		'description' =>  sanitize_text_field($_POST["bio-info"]),
		'role'  =>   'Subscriber' );
		}
		$user_id = wp_update_user($userdata);
		if ( is_wp_error( $user_id ) ) { echo '<div class="error"> Error! in update the User... </div>';  } else {  ?>
		<script>
		window.setTimeout(function(){
		var view_subscribers = '<?php echo admin_url( 'admin.php?page=sofgviewsubscribers.php'); ?>';
        window.location.href = view_subscribers;
    }, 50);
    </script>
		<?php exit; }
	}
	else if(isset($_GET["user_id"])){
		$user = get_user_by( 'id', intval($_GET["user_id"]) );
?>
<form action="<?php echo admin_url( 'admin.php?page=sofgeditsubscribers.php');?>" method="post">
<table cellspacing='0' id="SOFG-table"> <!-- cellspacing='0' is important, must stay -->
<tr><th colspan="2"><center><h2>Add Subscriber</h2></center></th></tr>
<tr><th>Username</th><td><input type="text" name="username" id="username" size="50" value="<?php echo $user->user_login; ?>" readonly /></td></tr>
<tr><th>Firstname</th><td><input type="text" name="firstname" id="firstname" size="50" value="<?php echo $user->first_name; ?>" /></td></tr>
<tr><th>Lastname</th><td><input type="text" name="lastname" id="lastname" size="50" value="<?php echo $user->last_name; ?>" /></td></tr>
<tr><th>E-mail</th><td><input type="email" name="email" id="email" size="50" value="<?php echo $user->user_email; ?>" required /></td></tr>
<tr><th>Website</th><td><input type="url" name="website" id="website" value="<?php echo $user->user_url; ?>" size="50" /></td></tr>
<tr><th>Biological Information</th><td><TEXTAREA name="bio-info" id="bio-info" rows="5" cols="50"><?php echo $user->description; ?></TEXTAREA></td></tr>
<tr><th>Password</th><td><input type="password" name="password" id="password" size="50" onchange="form.cpassword.pattern = this.value;" /></td></tr>
<tr><td colspan="2"><input type="hidden" name="sofguserid" id="sofguserid" value="<?php echo $user->ID; ?>" /><input type="submit" class="button button-primary" name="update_subscriber" id="update_subscriber" value="Update Subscriber" /></td></tr>
</table>
</form>
<?php }
else{ ?>
<script>
	 window.setTimeout(function(){
		var view_subscribers = '<?php echo admin_url( 'admin.php?page=sofgviewsubscribers.php');?>';
        // Move to a new location or you can do something else
        window.location.href = view_subscribers;
    }, 30);
</script>
<?php } ?>
