<div class="wrap">
<h2> SOFG : Plugin Setting </h2>
<p><strong>Page Shortcode : </strong> <span>[SOFG_NEWSLETTER_FRONT]</span> <strong> page Template Shortcode : </strong> <span> echo do_shortcode( '[SOFG_NEWSLETTER_FRONT]' ); </span> </p>
<form method="post" action="options.php">
	<?php settings_fields( 'sofg-plugin-settings-group' ); ?>
    <?php do_settings_sections( 'sofg-plugin-settings-group' ); ?>
    <table class="form-table">
        
        <tr valign="top">
        <th scope="row">Sender Name : </th>
        <td><input type="text" name="sofg_sender_name" value="<?php echo esc_attr( get_option('sofg_sender_name') ); ?>" size="50" /></td>
        </tr>
         
        <tr valign="top">
        <th scope="row">Sender Email Address </th>
        <td><input type="text" name="sofg_sender_email" value="<?php echo esc_attr( get_option('sofg_sender_email') ); ?>" size="50" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Reply to : </th>
        <td><input type="text" name="sofg_replyto" value="<?php echo esc_attr( get_option('sofg_replyto') ); ?>" size="50" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">CC to : </th>
        <td><input type="text" name="sofg_ccto" value="<?php echo esc_attr( get_option('sofg_ccto') ); ?>" size="50" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Email Image path (200*5) : </th>
        <td><input type="text" name="sofg_image_url" value="<?php echo esc_attr( get_option('sofg_image_url') ); ?>" size="50" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Email head Text : </th>
        <td><input type="text" name="sofg_email_text" value="<?php echo esc_attr( get_option('sofg_email_text') ); ?>" size="50" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Confirmation Email Subject : </th>
        <td><input type="text" name="sofg_confirm_email_subject" value="<?php echo esc_attr( get_option('sofg_confirm_email_subject') ); ?>" size="50" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Confirmation Message : </th>
        <td><TEXTAREA name="sofg_confirmation_message" rows="6" cols="50" /><?php echo get_option('sofg_confirmation_message') ; ?></TEXTAREA></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Welcome Email Subject : </th>
        <td><input type="text" name="sofg_welcome_email_subject" value="<?php echo esc_attr( get_option('sofg_welcome_email_subject') ); ?>" size="50" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Welcome Message : </th>
        <td><TEXTAREA name="sofg_welcome_message" rows="6" cols="50" /><?php echo get_option('sofg_welcome_message'); ?></TEXTAREA></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Unsubscribe Email Subject : </th>
        <td><input type="text" name="sofg_unsubscribe_email_subject" value="<?php echo esc_attr( get_option('sofg_unsubscribe_email_subject') ); ?>" size="50" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Unsubscribe Message : </th>
        <td><TEXTAREA name="sofg_unsubscribe_message" rows="6" cols="50" /><?php echo get_option('sofg_unsubscribe_message'); ?></TEXTAREA></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Enable Subscription List : </th>
        <td><input type="radio" name="en_subscription_list" value="true" <?php checked( get_option('en_subscription_list'), "true" ); ?>  /><span><label>true</span></label><input type="radio" name="en_subscription_list" value="false" <?php checked( get_option('en_subscription_list'), "false" ); ?> /><span><label>false</span></label></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Enable Autoupdate User : </th>
        <td><input type="radio" name="en_auto_update" value="true" <?php checked( get_option('en_auto_update'), "true" ); ?>  /><label><span>true</span></label><input type="radio" name="en_auto_update" value="false" <?php checked( get_option('en_auto_update'), "false" ); ?> /><span><label>false</span></label></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">View Number of subscribers in subscriber page : </th>
        <td><input type="text" name="sofg_view_no_subscribers" value="<?php echo esc_attr( get_option('sofg_view_no_subscribers') ); ?>" size="50" /></td>
        </tr>
        
    </table>
    
    <h1> Email Contact Information </h1>
    <table class="form-table">
    <tr valign="top">
    <th scope="row">facebook : </th>
    <td><input type="text" name="sofg_fb_contact" value="<?php echo esc_attr( get_option('sofg_fb_contact') ); ?>" size="50" /></td>
    </tr>
    
    <tr valign="top">
    <th scope="row">Twitter : </th>
    <td><input type="text" name="sofg_tw_contact" value="<?php echo esc_attr( get_option('sofg_tw_contact') ); ?>" size="50" /></td>
    </tr>
    
    <tr valign="top">
    <th scope="row">Google Plus : </th>
    <td><input type="text" name="sofg_gp_contact" value="<?php echo esc_attr( get_option('sofg_gp_contact') ); ?>" size="50" /></td>
    </tr>
    
    <tr valign="top">
    <th scope="row">Phone Number : </th>
    <td><input type="text" name="sofg_phnumber" value="<?php echo esc_attr( get_option('sofg_phnumber') ); ?>" size="50" /></td>
    </tr>
    
    <tr valign="top">
    <th scope="row">Email : </th>
    <td><input type="text" name="sofg_email_contact" value="<?php echo esc_attr( get_option('sofg_email_contact') ); ?>" size="50" /></td>
    </tr>
    
    <tr valign="top">
    <th scope="row">Term and Condition Page URL :  </th>
    <td><input type="text" name="sofg_tandc_url" value="<?php echo esc_attr( get_option('sofg_tandc_url') ); ?>" size="50" /></td>
    </tr>
    
    <tr valign="top">
    <th scope="row">Privacy Page URL :</th>
    <td><input type="text" name="sofg_privacy_url" value="<?php echo esc_attr( get_option('sofg_privacy_url') ); ?>" size="50" /></td>
    </tr>
	</table>
    <?php submit_button(); ?>
</form>
</div>
