<?php
	@session_start();
?>
<?php
	//wp_enqueue_style( 'sofg-plugin-style' );
?>
<script>
function sofg_email_validate(nemail) {
    var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
    if(!pattern.test(nemail)){  jQuery('#erro').show(); return false;  }
    else{jQuery('#erro').hide(); return true; }
    //return pattern.test(nemail);
}
</script>
<?php //echo plugins_url( 'sofg-newsletter/actions/SOFG-actions.php' ); ?>
<div class="news-let" style="float: left;width: 100%;text-align: center;padding: 30px;">
<form action="" onsubmit="return false" method="post" onsubmit="return sofg_email_validate(sofg_email.value);" >
	<input type="text" name="sofg_email" id="nwsemail" value="" placeholder="enter your email"></input>
	<input type="hidden" name="user_news_subscription" value="all" />
	<!-- <input type="submit" id="nwssubmit" name="sofg_subscribe" value="Subscribe"> -->
	<button onclick="emailsubmit()" id="">Submit</button>
</form>
<p class="erro"></p>
<p class="success"></p>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js" ></script>
	
<script>
		function emailsubmit(){
			jQuery('.erro').html('');	
			jQuery('.success').html('');
			var email = document.getElementById('nwsemail').value;
			if(email != ''){
				var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            	if(re.test(email)){
            		jQuery.ajax({
		                url: "<?php echo plugins_url( 'sofg-newsletter/actions/SOFG-actions.php' ); ?>",
		                data: {sofg_email:email},
		                type: 'POST',
		                beforeSend: function () {
		                   jQuery("#loader-wrapper1").show();
		                },
		                complete: function () {
		                   jQuery("#loader-wrapper1").hide();
		                },
		                success: function (data) {
		                	if(data == 'success'){
			                    jQuery('.success').html('Your email subscribe successfully');
			                	jQuery("form").trigger("reset");
			                }
			                if(data == 'NoSuccess'){
			                	jQuery('.success').html('Email already subscribe');
			                }
		                }
		            });
            	} else {
            		jQuery('.erro').html('Please Enter Valid Email');
            	}
			} else {
				jQuery('.erro').html('Please Enter email address');
			}
		}
</script>




