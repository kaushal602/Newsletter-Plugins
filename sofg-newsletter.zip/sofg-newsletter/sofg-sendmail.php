<?php
	wp_enqueue_style( 'sofg-plugin-style' );
	if(isset($_POST["send_mail"])){
			$sender_name = get_option('sofg_sender_name');
			$sender_email = get_option('sofg_sender_email');
			$reply_email = get_option('sofg_replyto');
			$cc_email = get_option('sofg_ccto');
			$message = sanitize_text_field($_POST["sofg_editor"]);
			$email = sanitize_email($_POST["emails"]);
			$subject = sanitize_text_field($_POST["email_subject"]);
			$headers = "From: ".$sender_name." ".strip_tags($sender_email)."\r\n";
			$headers .= "Reply-To: ". strip_tags($reply_email) . "\r\n";
			$headers .= "CC: ".$cc_email."\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			wp_mail( $email, $subject, $message, $headers);	
			/* echo '<div class="message"> Send Mail Successfully! </div>'; }
			else{ echo '<div class="error"> Probliem in Send Mail. </div>'; } */
	}
	$sofg_email_receiver = '';
	if(isset($_GET['sofg_send_mail'])){
			if($_GET['sofg_send_mail']=="all"){ 
				$args = array('role'=> 'Subscriber');
				$SOFG_Subscribers = get_users( $args );
				foreach($SOFG_Subscribers as $SOFG_Subscriber){
						$sofg_email_receiver .= $SOFG_Subscriber->user_email.",";
				}
				
			}
			else{
					$sofg_email_receiver = sanitize_email($_GET['sofg_send_mail']);
				}
	}
?>
<form action="<?php echo admin_url( 'admin.php?page=sofgmailsubscribers.php');?>" method="post">
<table cellspacing='0' id="SOFG-table"> <!-- cellspacing='0' is important, must stay -->
<tr><th colspan="2"><center><h2>Send Mail To Subscriber</h2></center></th></tr>
<tr><th>EMail(s)<span>separated by commas(,)</span></th><td><input type="text" name="emails" id="emails" size="100" value="<?php echo $sofg_email_receiver; ?>" required /></td></tr>
<tr><th>Subject</th><td><input type="text" name="email_subject" id="email_subject" size="100" required /></td></tr>
<tr><th>Mail Contents</th><td><?php 
$content = '';
$editor_id = 'sofg_editor';
$settings = array( 'wpautop'=> false,'textarea_name'=> $editor_id );
wp_editor( $content, $editor_id, $settings ); ?></td></tr>
<tr><td colspan="2"><input type="submit" class="button button-primary" name="send_mail" id="send_mail" value="Send Mail Subscriber" /></td></tr>
</table>
</form>
