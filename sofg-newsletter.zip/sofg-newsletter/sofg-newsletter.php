<?php
/*
Plugin Name: SOFG Newsletter
Plugin URI:  https://anandnayi.wordpress.com/
Description: This is realy awesome plugin to send email to subscribers users and newsletter subscriptions.It has also auto new feature to send auto update to related subscribe category. Use this short code <span> [SOFG_NEWSLETTER_FRONT] </span> to display newsletter frontend.
Version:     1.5
Author:      Anand Nayi
Author URI:  https://anandnayi.wordpress.com/about/
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: sofg-language
*/

/*  2015  Anand Nayi  (email : anand.nayi@gmail.com) */

define('SOFG_BASENAME', trailingslashit(basename(dirname(__FILE__))));
define('SOFG_DIR', WP_CONTENT_DIR . '/plugins/' . SOFG_BASENAME);
define('SOFG_URL', WP_CONTENT_URL . '/plugins/' . SOFG_BASENAME);

class SOFG__Newsletter
{
	public $option = 'sofg-options';
    public $options = null;
    
    /**
	 * @TODO Add class constructor description.
	*/
	 function __construct() {
		// Register style sheet.
		add_action( 'wp_enqueue_scripts', array( $this, 'SOFG_plugin_styles' ) );
	}
	
	/**
	 * Register and enqueue style sheet.
	 */
	 public function SOFG_plugin_styles() {
		// wp_register_style( 'sofg-plugin-style', plugins_url( 'sofg-newsletter/css/SOFG-style.css' ) );
		// wp_enqueue_style( 'sofg-plugin-style' );
	}
	
	public function initialize_default_sofg_options()
    {
        update_option('sofg_confirm_email_subject',"SOFG Confirm Email Subject");
        update_option('sofg_image_url',"http://placehold.it/200x50");
        update_option('sofg_email_text',"SOFG Text");
        update_option('sofg_welcome_email_subject',"SOFG WELCOME Email Subject");
        update_option('sofg_unsubscribe_email_subject',"SOFG : Successfully Unsubscribes");
        update_option('en_subscription_list',"false");
        update_option('en_auto_update',"false");
        update_option('sofg_view_no_subscribers',10);
        update_option('sofg_fb_contact',"#");
        update_option('sofg_tw_contact',"#");
        update_option('sofg_gp_contact',"#");
        update_option('sofg_phnumber',9999999999);
        update_option('sofg_tandc_url',"#");
        update_option('sofg_privacy_url',"#");
    }
    
}

function register_sofgnlplugin_menu_page()
{
    $menuSlug = 'sofg-setting.php';
    $capability = 'manage_options';
    add_menu_page('SOFG', 'SOFG Setting', $capability, $menuSlug, 'SOFGNL_settings',plugins_url( 'sofg-newsletter/sofg-logo.png' ));
    add_submenu_page( $menuSlug, 'SOFG : View Subscribers', 'View Subscribers', $capability, 'sofgviewsubscribers.php', 'viewSubscribers' );
    add_action( 'admin_init', 'register_sofg_plugin_settings' );
    add_submenu_page( $menuSlug, 'SOFG : Add Subscribers', 'Add Subscribers', $capability, 'sofgaddsubscribers.php', 'addSubscribers' );
    add_submenu_page( $menuSlug, 'SOFG : Edit Subscribers', 'Edit Subscribers', $capability, 'sofgeditsubscribers.php', 'editSubscribers' );
    add_submenu_page( $menuSlug, 'SOFG : Mail Subscribers', 'Mail Subscribers', $capability, 'sofgmailsubscribers.php', 'mailSubscribers' );
}

function register_sofg_plugin_settings() {
	//register our settings
	register_setting( 'sofg-plugin-settings-group', 'sofg_confirm_email_subject' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_sender_name' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_sender_email' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_replyto' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_ccto' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_image_url' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_email_text' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_confirmation_message' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_welcome_email_subject' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_welcome_message' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_unsubscribe_email_subject' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_unsubscribe_message' );
	register_setting( 'sofg-plugin-settings-group', 'en_subscription_list' );
	register_setting( 'sofg-plugin-settings-group', 'en_auto_update' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_view_no_subscribers' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_fb_contact' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_tw_contact' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_gp_contact' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_phnumber' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_email_contact' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_tandc_url' );
	register_setting( 'sofg-plugin-settings-group', 'sofg_privacy_url' );
}

function SOFGNL_settings()
{
	include SOFG_DIR.'SOFG_setting.php'; 
}

function viewSubscribers(){
	wp_register_style( 'sofg-plugin-style', plugins_url( 'sofg-newsletter/css/SOFG-style.css' ) );
	wp_register_style( 'sofg-plugin-font-awesome', plugins_url( 'sofg-newsletter/css/font-awesome.css' ) );
	wp_register_style( 'sofg-plugin-font-awesome-min', plugins_url( 'sofg-newsletter/css/font-awesome.min.css' ) );
	include SOFG_DIR.'viewSubscribers.php'; 
}

function addSubscribers(){
	wp_register_style( 'sofg-plugin-style', plugins_url( 'sofg-newsletter/css/SOFG-style.css' ) );
	include SOFG_DIR.'addSubscribers.php'; 
}

function editSubscribers(){
	wp_register_style( 'sofg-plugin-style', plugins_url( 'sofg-newsletter/css/SOFG-style.css' ) );
	include SOFG_DIR.'editSubscribers.php'; 
}

function mailSubscribers(){
	wp_register_style( 'sofg-plugin-style', plugins_url( 'sofg-newsletter/css/SOFG-style.css' ) );
	include SOFG_DIR.'sofg-sendmail.php'; 
}

function sofg_newsletter_frontend(){
	wp_register_style( 'sofg-plugin-style', plugins_url( 'sofg-newsletter/css/SOFG-style.css' ) );
	include SOFG_DIR.'newsletter_front_end_html.php'; 
}

$aaiufile = WP_CONTENT_DIR . '/plugins/' . basename(dirname(__FILE__)) . '/' . basename(__FILE__);

$aaui = new SOFG__Newsletter();

add_action('admin_menu', 'register_sofgnlplugin_menu_page');

function sofg_auto_update_email( $ID, $post ) {
	if(get_option('en_auto_update')=="true"){
	$post_title = get_the_title( $ID );
	$post_url = get_permalink( $ID );
	$subject = 'A post has been updated';
	$message = "A post has been updated on your website:\n\n";
	$message .= $post_title. ": " . $post_url;
	$post_categories = wp_get_post_categories( $ID );
	$filter_email = array();
	if(!empty($post_categories)){
			for($i=0; $i<count($post_categories); $i++){
					$args = array('role'=> 'Subscriber','meta_key' => 'sofg_newsl_status','meta_value' => '1');
					$SOFG_Subscribers = get_users( $args );
					foreach($SOFG_Subscribers as $SOFG_Subscriber){
						if(get_option('en_subscription_list')=="true") {
						$sofg_users_up_cat = get_user_meta($SOFG_Subscriber->ID,"sofg_newsl_update",true);
						if(in_array($post_categories[$i],$sofg_users_up_cat)){ $filter_email[] = $SOFG_Subscriber->user_email;  }
					}else{ $filter_email[] = $SOFG_Subscriber->user_email; }
					}
			}
	}
	$filter_email_final = array_unique($filter_email);
	wp_mail( $filter_email_final, $subject, $message );
}
}
add_action( 'publish_post', 'sofg_auto_update_email', 10, 2 );
$aaiufile = WP_CONTENT_DIR . '/plugins/' . basename(dirname(__FILE__)) . '/' . basename(__FILE__);
$sofg_obj = new SOFG__Newsletter();
register_activation_hook($aaiufile, array($sofg_obj, 'initialize_default_sofg_options'));
add_shortcode( 'SOFG_NEWSLETTER_FRONT', 'sofg_newsletter_frontend' );
?>
