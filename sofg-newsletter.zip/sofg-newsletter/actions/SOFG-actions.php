<?php session_start();
	include '../../../../wp-load.php';
	//if(isset($_POST['sofg_subscribe'])){
		$email = sanitize_email($_POST['sofg_email']);

		global $wpdb;
		$chkmail = $wpdb->get_results("select ID from wp_users where user_email like '".$_POST['sofg_email']."'");

		$users_news_category = $_POST['user_news_subscription'];
		if(empty($chkmail)) {

			/*global $wpdb;
			$wpdb->insert( 
				'wp_subscriber', 
					array( 
					'email' => $email, 
					'wp_capabilities' 	=> 'Subscriber',
					'sofg_newsl_status' => 0,
					'newsletters' => 1
					)
			);*/
		
			$userdata = array('user_login' => $email,'user_email' => $email,'user_pass' => NULL,'role' =>'Subscriber' );
			$user_id = wp_insert_user ($userdata);
			add_user_meta( $user_id, "sofg_newsl_status", 1);
			//add_user_meta( $user_id, "sofg_newsl_update", $users_news_category);
			add_user_meta( $user_id,"newsletters",'1');
		
			$confirmation_mail = get_option('sofg_confirmation_message');
			$sender_name = get_option('sofg_sender_name');
			$sender_email = get_option('sofg_sender_email');
			$reply_email = get_option('sofg_replyto');
			$cc_email = get_option('sofg_ccto');
			/*$user_id_encode = base64_encode($email);
			$confirm_link = site_url()."?confirm=".$user_id_encode;
			$sofg_facebook = get_option('sofg_fb_contact');
			$sofg_twitter = get_option('sofg_tw_contact');
			$sofg_gplus = get_option('sofg_gp_contact');
			$sofg_phonenumber = get_option('sofg_phnumber');
			$sofg_term_condition = get_option('sofg_tandc_url');
			$sofg_privacy = get_option('sofg_privacy_url');
			$sofg_memail = get_option('sofg_email_contact');
			$sofg_image_url = get_option('sofg_image_url');
			$sofg_email_text = get_option('sofg_email_text');
			$sofg_unsubscribe = plugins_url( 'sofg-newsletter/actions/SOFG-actions.php' )."?unsubscribe=".$user_id_encode;*/
			$email1= $sender_email;			
			$admin_email = $_POST['sofg_email'];
			$subject = 'Subscription email';
			$headers  = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			//$headers .= 'From: info@greenery <'.$email1.'>' . "\r\n";
			//$headers .= 'Reply-To: info@greenery'."\r\n";
			$message = '<html xmlns="http://www.w3.org/1999/xhtml">';
			$message .= '<head>';
			$message .= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
			$message .= '<meta name="viewport" content="width=device-width, initial-scale=1">';
			$message .= '<title>Confirm Email</title>';
			$message .= '<link href="http://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700,800" rel="stylesheet" type="text/css">';
			$message .= '</head>';
			$message .= '<body style=" background-color:#e5e5e5;">';
			$message .= '<article>';
			$message .= '<section>';
			$message .= '<div class="container">';
			$message .= '<div class="row">';
			$message .= '<div class="nill-box-alr" style="float: left;width: 60%; margin:8% 20%;font-family:Raleway;">';
			$message .= '<div class="bor-sec" style=" border: 1px solid #e5e5e5; border-radius: 10px 10px 0 0;float: left; background-color:#fff;">';
			$message .= '<div class="hed-ty-sec" style=" border-radius:10px 10px 0 0;float:left; width:100%; margin-bottom:15px; background:url(http://www.nillowpages.com/wp-content/themes/yellow_pages/images/header_stars.png) no-repeat scroll center center, rgba(0, 0, 0, 0) linear-gradient(#c41200, #af0606) repeat scroll 0 0 ;">';
			$message .= '<div class="col-md-3 col-sm-3 col-xs-12 dm-se-lg" style="float: none;margin: 0 auto;text-align: center; padding:15px;background-color: #fff;">';
			//$message .= '<img src="'.get_template_directory_uri().'/images/green-logo.png" width="50%"/>';
			$message .= '<img src="http://thewirelessgalaxy.embedinfosoft.com/wp-content/themes/thewirelessgalaxy-child/assets/images/logo.png" width="50%"/>';
			$message .= '</div>';
			$message .= '</div>';
			$message .= '<div class="col-md-12 col-sm-12 col-xs-12">';
			$message .= '<div class="mai-tit-sec" style=" float:left; width:100%;">';
			$message .= '<p class="tit-wel-sec" style="float:left; text-align:center; margin:0;font-size: 15px;font-weight: bold;width:100%;">Welcome to 2018 The Wireless Galaxy!</p>';
			$message .= '<p class="tit-wel-sec" style="float:left; width:96%; text-align:center; margin:9px 0; width:100%;">Thank you for Subscribing to The Wireless Galaxy, your subscription to The Wireless Galaxy newsletter has been confirmed</p>';
			//$message .= '<span style="float:left; width:96%; padding:0 15px; color:#A4A4A4;">-The BUYERS CHOICE Team</span>';
			$message .= '</div>';
			$message .= '</div>';
			$message .= '</div>';
			$message .= '<div class="col-md-12 col-sm-12 col-xs-12">';
			$message .= '<div class="fot-sec-po" style="float:left; width:100%;">';
			$message .= '<p class="foot-lst-sec" style=" text-align:center;float:left; width:96%; margin:0; padding:15px; word-wrap:break-word;">2018 The Wireless Galaxy</p>'; 
			$message .= '</div>';
			$message .= '</div>';
			$message .= '</div>';
			$message .= '</div>';
			$message .= '</div>';
			$message .= '</section>';
			$message .= '</article>';
			$message .= '</body>';
			$message .= '</html>';				
			
		    mail( $admin_email, $subject, $message, $headers);

		    echo $_SESSION['success_home'] = "You have successfully subscribe";    
		    //wp_redirect(get_permalink(4));
			}
			else{
				 echo $_SESSION['error_home'] = "This user is already exists";
				 //wp_redirect(get_permalink(4));
			}
			echo '<script> sofg_message_redirect(); </script>';
 }
  /*if(isset($_GET['confirm'])){
	    $user_id_encode = $_GET['confirm'];
	    $user_id_decode = base64_decode($user_id_encode);
	    settype($user_id_decode, "integer");
	    $user_id_decode = intval($user_id_decode);
	    update_user_meta( $user_id_decode, "sofg_newsl_status", 1);
	    $user = get_user_by('id', $user_id_decode);
		$email = $user->user_email;
		$welcome_message = get_option('sofg_welcome_message');	
	    $confirmation_mail = get_option('sofg_confirmation_message');
		$sender_name = get_option('sofg_sender_name');
		$sender_email = get_option('sofg_sender_email');
		$reply_email = get_option('sofg_replyto');
		$cc_email = get_option('sofg_ccto');
	    $subject = get_option('sofg_welcome_email_subject');
//	    echo '<h1>'.$subject.'</h1>';
	 //   echo '<p>'.$welcome_message.'</p>';
	    $headers = "From: ".$sender_name." ".strip_tags($sender_email)."\r\n";
	    $headers .= "Reply-To: ". strip_tags($reply_email) . "\r\n";
	    $headers .= "CC: ".$cc_email."\r\n";
	    $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        wp_mail( $email, $subject, $welcome_message, $headers);
        wp_redirect(home_url());
	 }
	 if(isset($_GET['unsubscribe'])){
	    $user_id_encode = $_GET['unsubscribe'];
	    $user_id_decode = base64_decode($user_id_encode);
	    $user_id_decode = intval($user_id_decode);
	    settype($user_id_decode, "integer");
	    $user = get_user_by('id', $user_id_decode);
		$email = $user->user_email;
		include '../../../../wp-load.php';
		require ABSPATH.'wp-admin/includes/user.php';
	    wp_delete_user($user_id_decode);
	    $unsubscribe_message = get_option('sofg_unsubscribe_message');	
		$sender_name = get_option('sofg_sender_name');
		$sender_email = get_option('sofg_sender_email');
		$reply_email = get_option('sofg_replyto');
		$cc_email = get_option('sofg_ccto');
	    $subject = get_option('sofg_unsubscribe_email_subject');
	    echo '<h1>'.$subject.'</h1>';
	    echo '<p>'.$unsubscribe_message.'</p>';
	    $headers = "From: ".$sender_name." ".strip_tags($sender_email)."\r\n";
	    $headers .= "Reply-To: ". strip_tags($reply_email) . "\r\n";
	    $headers .= "CC: ".$cc_email."\r\n";
	    $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        wp_mail( $email, $subject, $unsubscribe_message, $headers);
        wp_redirect(home_url());
	 }*/
?>

