<?php 
	include '../../../../wp-load.php';
	echo "dsfjh";
?>
